﻿namespace ClearentTest
{
    class Card
    {
        public int ID { get; set; }
        public string ProviderName { get; set; }
        public decimal InterestRate { get; set; }
        public decimal Balance { get; set; }
    }
}
