﻿using System.Collections.Generic;

namespace ClearentTest
{
    class CardHolder
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public List<Wallet> Wallets { get; set; }
    }
}
