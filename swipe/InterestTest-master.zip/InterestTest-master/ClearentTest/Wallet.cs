﻿using System.Collections.Generic;

namespace ClearentTest
{
    class Wallet
    {
        public int ID { get; set; }
        public List<Card> Cards { get; set; }
    }
}
